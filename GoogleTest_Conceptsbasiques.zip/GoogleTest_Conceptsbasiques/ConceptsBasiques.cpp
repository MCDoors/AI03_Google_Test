//
// Created by guillaume on 09/01/2020.
//

#include "ConceptsBasiques.hpp"
#include <iostream>
using namespace std;

float surface(int r){ // Fonction qui renvoie la surface d'un disque de rayon r.
    float surface;
    if (r < 0) {
        surface = -1; // Choix arbitraire.
    }
    else {
        const float Pi = 3.14;
        surface = Pi*r; // Erreur volontaire pour afficher un test qui échoue.
    }
    if (surface == -1) {
        cout << "Erreur, le rayon est négatif." << endl;
    }
    else {
        cout << "La surface vaut " << surface << "m²." << endl;
    }

    return(surface);
}

// setFraction n'est pas inline : elle est définie dans le fichier fraction.cpp
void Fraction::setFraction(int n, int d) {
    numerateur = n;
    denominateur = d;
    if(d==0) {
        cerr << "erreur : denominateur = 0" << endl;
        denominateur = 1; // Choix arbitraire
    }
    simplification();
}

void Fraction::simplification(){
    // si le numerateur est 0, le denominateur prend la valeur 1
    if (numerateur==0) { denominateur=1; return; }
    /* un denominateur ne devrait pas être 0;
    si c’est le cas, on sort de la méthode */
    if (denominateur==0) return;
    /* utilisation de l’algorithme d’Euclide pour trouver le Plus Grand Commun
    Denominateur (PGCD) entre le numerateur et le denominateur */
    int a=numerateur, b=denominateur;
    // on ne travaille qu’avec des valeurs positives...
    if (a<0) a=-a; if (b<0) b=-b;
    while(a!=b){ if (a>b) a=a-b; else b=b-a; }
    // on divise le numerateur et le denominateur par le PGCD=a
    numerateur/=a; denominateur/=a;
    // si le denominateur est négatif, on fait passer le signe - au denominateur
    if (denominateur<0) { denominateur=-denominateur; numerateur=-numerateur; }
}

const Fraction Fraction::somme(const Fraction & f) const {
    return Fraction(numerateur*f.denominateur+denominateur*f.numerateur, denominateur*f.denominateur);
}
