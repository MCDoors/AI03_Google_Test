//
// Created by guillaume on 09/01/2020.
//

#ifndef CONCEPTSBASIQUES_HPP
#define CONCEPTSBASIQUES_HPP

#include <iostream>
using namespace std;

float surface(int r);

class Fraction {
private:
    int numerateur;
    int denominateur;
    void simplification(); // Méthode simplifiant les fractions
public:
    Fraction(int n=0, int d=1) {
        // Appel à setFraction qui contrôle la validité des valeurs renseignées
        setFraction(n, d);
        cout << "Constructeur " << numerateur << "/" << denominateur << " : " << this << endl;
    }
    ~Fraction() {
        cout << "Destructeur " << numerateur << "/" << denominateur << " : " << this << endl;
    }

    int getNumerateur() const { return this->numerateur;}
    int getDenominateur() const { return this->denominateur;}
    void setFraction(int n, int d);

    Fraction const somme(Fraction const & f) const; // Calcule la somme de deux fractions
    // Syntaxe : f1.somme(f2)
};

#endif // CONCEPTSBASIQUES_HPP
