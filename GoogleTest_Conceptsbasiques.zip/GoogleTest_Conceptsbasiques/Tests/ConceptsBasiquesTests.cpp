//
// Created by guillaume on 09/01/2020.
//

#include <gtest/gtest.h>
#include "../ConceptsBasiques.hpp"

TEST(SurfaceDisque, Zero) {
    EXPECT_EQ(0, surface(0));
}

TEST(SurfaceDisque, Positif) {
    EXPECT_FLOAT_EQ(3.14, surface(1));
    EXPECT_FLOAT_EQ(12.56, surface(2));
    EXPECT_FLOAT_EQ(28.26, surface(3));
    EXPECT_EQ(31400, surface(100));
    EXPECT_EQ(3140000, surface(1000));
}

TEST(SurfaceDisque, Negatif) {
    EXPECT_EQ(-1, surface(-1));
    EXPECT_EQ(-1, surface(-2));
    EXPECT_EQ(-1, surface(-100));
    EXPECT_EQ(-1, surface(-100000));
}

class FractionTest : public testing::Test {
    protected:

    void SetUp() override {
        f1 = new Fraction(1, 3);
        f2 = new Fraction(2, 3);
        f3 = new Fraction(0, 3);
        f4 = new Fraction(1, 0);
        f5 = new Fraction(2,4);
    }
    void TearDown() override {
        delete f1;
        delete f2;
        delete f3;
        delete f4;
        delete f5;
    }

    Fraction * f1;
    Fraction * f2;
    Fraction * f3;
    Fraction * f4;
    Fraction * f5;
};

TEST_F(FractionTest, Somme) {
    Fraction SumF1F2 = f1->somme(*f2);

    EXPECT_EQ(SumF1F2.getNumerateur(), 1);
    EXPECT_EQ(SumF1F2.getDenominateur(), 1);
}

TEST_F(FractionTest, DivisionZero) {
    ASSERT_NE(f1->getDenominateur(), 0);
    ASSERT_NE(f2->getDenominateur(), 0);
    ASSERT_NE(f3->getDenominateur(), 0);
    ASSERT_NE(f4->getDenominateur(), 0);
    ASSERT_NE(f5->getDenominateur(), 0);
}

TEST_F(FractionTest, Simplification) {
    EXPECT_EQ(f1->getNumerateur(), 1);
    EXPECT_EQ(f1->getDenominateur(), 3);

    EXPECT_EQ(f2->getNumerateur(), 2);
    EXPECT_EQ(f2->getDenominateur(), 3);

    EXPECT_EQ(f3->getNumerateur(), 0);
    EXPECT_EQ(f3->getDenominateur(), 1);

    EXPECT_EQ(f4->getNumerateur(), 1);
    EXPECT_EQ(f4->getDenominateur(), 1);

    EXPECT_EQ(f5->getNumerateur(), 1);
    EXPECT_EQ(f5->getDenominateur(), 2);
}